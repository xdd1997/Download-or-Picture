N=30
    
A = zeros(N,N);
b = zeros(N,1);
for i = 2:N-1
    A(i,i-1) = 8;
    A(i,i) = 6 ;
    A(i,i+1) = 1;
end
A(1,1) = 6;A(1,2) = 1;
A(N,N-1) = 8;A(N,N) = 6;

invA = inv(A)
save A
save invA