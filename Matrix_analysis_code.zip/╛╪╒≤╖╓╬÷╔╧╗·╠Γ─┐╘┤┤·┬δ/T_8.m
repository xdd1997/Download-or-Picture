function T_8()
    clc; clear all; close all;format long
 hs=[0.1,0.01,0.001];
for i=1:3
    h = hs(i)
    computer(h);
end

function [] =computer(h)
F='(x^2*y^2-y)/(x+1)^2';
a=0;
b=1;
n=(b-a)/h;%ȷ������
X=a:h:b;
Y=zeros(1,n+1);
Y(1)=1;
%�Ľ�Euler��ʽ
Y1=zeros(1,n+1);
Y1(1)=1;
for i=2:n+1
    x=X(i-1);
    y=Y1(i-1);
    ty=Y1(i-1)+eval(F)*h;
    Y1(i)=Y1(i-1)+h/2*eval(F);
    x=X(i);
    y=ty;
    Y1(i)=Y1(i)+h/2*eval(F);
end
fun=@(x,y)(x.^2*y.^2-y)/(x+1).^2;
N=(b-a)/h;%�������
t=a:h:b;
x(:,1)=1;
for i=1:N
    K1=fun(t(i),x(:,i)); %����K1 K2 K3 K4
    K2=fun(t(i)+h/2,x(:,i)'+(h/2)*K1);
    K3=fun(t(i)+h/2,x(:,i)'+(h/2)*K2);
    K4=fun(t(i)+h,x(:,i)'+h*K3);
    x(:,i+1)=x(:,i)'+(h/6)*(K1+2*K2+2*K3+K4);
end
Y2=x';
t=t';
% ���θ�ʽ
fun=@(x,y)(x.^2*y.^2-y)/(x+1).^2;
x(1)=0;y(1)=1; 
n=(b-a)/h;
for i=1:n 
x(i+1)=x(i)+h; 
y(i+1)=y(i)+h*feval(fun,x(i),y(i)); 
y(i+1)=y(i)+h*(feval(fun,x(i),y(i))+feval(fun,x(i+1),y(i+1)))/2;
end
x=x'; 
Y3=y';

result_1 = Y1(end)%�Ľ�ŷ�����Ľ�
result_2 = Y2(end)%����R-K��ʽ
result_3 = Y3(end)%���θ�ʽ
